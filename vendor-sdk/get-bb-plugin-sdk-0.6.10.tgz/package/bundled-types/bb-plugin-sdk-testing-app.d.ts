// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

import { ReactNode, ComponentType } from 'react';
import { RenderResult } from '@testing-library/react';
import { ExperimentalSidebarFooterItemRegistration, PluginProviderIconRegistration, PluginHomepageSectionRegistration, PluginSettingsSectionRegistration, ExperimentalAppOverlayRegistration, PluginNavPanelRegistration, PluginThreadPanelActionRegistration, PluginNewThreadPanelActionRegistration, ComposerCustomization, PluginPendingInteractionRegistration, PluginSidebarFooterActionRegistration, ExperimentalSidebarNavigationRegistration, ExperimentalSidebarHeaderRegistration, PluginThreadListRegistration, PluginThreadHeaderActionRegistration, ExperimentalPluginBrowserToolbarActionRegistration, PluginFileOpenerRegistration, PluginSourceCodeRendererRegistration, PluginDiffRendererRegistration, PluginMessageDirectiveRegistration, PluginMessageActionRegistration, ExperimentalIconRegistration, PluginTimelineRendererRegistration, PluginEnvironmentProviderInputsRegistration, PluginMachineProviderInputsRegistration, PluginContentScriptRegistration, ComposerDraftSnapshot, PluginComposerScope, ComposerSelection, PluginComposerTextEffect, PluginComposerMention, ComposerSubmitOptions, PluginComposerThreadRowStatus, ExperimentalOpenFixedTabOptions, JsonValue, BbNavigate, ExperimentalFileOpenOptions, PluginAppDefinition, PluginRpcContract, StandardSchemaV1InferInput, PluginRpcResult, PluginBrowserBbSdk, PluginRealtimeConnectionState, ComposerMention, ComposerAttachment, PluginSidebarThreadsState, PluginProvidersState, PluginCodeThemeState, BranchesState, CheckoutState, PluginSidebarPullRequest, PluginSidebarThreadRowStatus, PluginSidebarThreadShortcut, PluginSidebarSplitLayout, ExperimentalSidebarNavigationItem, PluginEnvironmentProvidersState, PluginSidebarThreadActions, ExperimentalSidebarNavigationActions } from '@get-bb/plugin-sdk';

type ExperimentalSidebarFooterCommandKind = "close" | "open" | "toggle";
interface ExperimentalSidebarFooterRuntimeSnapshot {
    command: {
        sequence: number;
        kind: ExperimentalSidebarFooterCommandKind;
    } | null;
}
interface ExperimentalSidebarFooterItemRuntime {
    subscribe(listener: () => void): () => void;
    getSnapshot(): ExperimentalSidebarFooterRuntimeSnapshot;
    acknowledgeCommand(sequence: number): void;
}
type CollectedExperimentalSidebarFooterItem = ExperimentalSidebarFooterItemRegistration & {
    runtime: ExperimentalSidebarFooterItemRuntime;
};
type CollectedPluginProviderIconRegistration = Omit<PluginProviderIconRegistration, "providerKind"> & {
    providerKind: PluginProviderIconRegistration["providerKind"] | "all";
};

/**
 * `@get-bb/plugin-sdk/testing/app` — the frontend plugin test harness. Tests a
 * plugin's `app.tsx` source directly under vitest + jsdom, without the bb
 * host or the esbuild bundle:
 *
 * - {@link installTestPluginRuntime} fills `globalThis.__bbPluginRuntime.
 *   pluginSdkApp` with a test implementation of the `@get-bb/plugin-sdk/app`
 *   surface (the same seam `bb plugin build` shims to the real app). The
 *   `@get-bb/plugin-sdk/app` exports look the runtime up when they are called
 *   or rendered, so import order does not matter: install the runtime any time
 *   before the first hook runs ({@link loadPluginApp} and {@link renderSlot}
 *   install it for you).
 * - {@link loadPluginApp} runs the definition's setup against a validating
 *   collector (ported from the BB app's interpreter, same error messages)
 *   and returns the typed slot registrations.
 * - {@link renderSlot} mounts one registration's component with mock hook
 *   backends: rpc as a method→handler map with a call log, realtime as a
 *   channel you can push events into, settings/context as plain values, and
 *   navigate/composer as recorders. Its `behavior`, `inspection`, and
 *   `lifecycle` views separate host inputs, assertions, and mount controls;
 *   the existing direct members remain aliases.
 *
 * Add `// @vitest-environment jsdom` to test files using renderSlot.
 */
interface RpcCall {
    method: string;
    input: unknown;
}
/** One recorded `useSdk()` call, as `"<area>.<method>"` plus its arguments. */
interface SdkCall {
    method: string;
    args: unknown[];
}
type PluginSdkFakeTree<T> = {
    [Key in keyof T]?: T[Key] extends (...args: never[]) => unknown ? T[Key] : PluginSdkFakeTree<T[Key]>;
};
/**
 * Nested partial fakes for `useSdk()`, mirroring the client's areas and
 * sub-areas (`{ threads: { queuedMessages: { create } } }`). Provide only the
 * methods the slot calls; a call to anything else throws with the missing
 * dot-path so the test fails loudly instead of returning undefined.
 */
type PluginSdkTestFakes = PluginSdkFakeTree<PluginBrowserBbSdk>;
type NavigateCall = {
    method: "toThread";
    threadId: string;
} | {
    method: "toProject";
    projectId: string;
} | {
    method: "toPluginPanel";
    path: string;
    options?: {
        subPath?: string;
        replace?: boolean;
    };
} | {
    method: "toCompose";
    options?: {
        initialPrompt?: string;
        focusPrompt?: boolean;
    };
} | {
    method: "openThreadPanel";
    options: Parameters<BbNavigate["openThreadPanel"]>[0];
} | {
    method: "openUrl";
    url: string;
} | {
    method: "experimental_openFilePreview";
    options: ExperimentalFileOpenOptions;
} | {
    method: "experimental_openFileExternally";
    options: ExperimentalFileOpenOptions;
};
interface ExperimentalFixedTabOpenCall {
    surface: ExperimentalOpenFixedTabOptions<JsonValue>["surface"];
    panelId: string;
    tabId: string;
    target?: JsonValue;
}
interface ComposerLog {
    /** Latest plain text in this isolated composer scope. */
    readonly text: string;
    /**
     * Latest text and mention pills, as `useComposer().draft` reports them.
     * The harness composer has no caret, so cursor inserts land at the end.
     */
    readonly draft: ComposerDraftSnapshot;
    /** The key `useComposer().key` reports for the current scope. */
    readonly key: string;
    /** Latest host-provided composer scope. */
    readonly scope: PluginComposerScope;
    /** Current picker snapshot, or null for a composer without pickers. */
    readonly selection: ComposerSelection | null;
    /** Latest host-provided attachment count exposed through `useComposerView()`. */
    readonly attachmentCount: number;
    /** Latest host-rendered text effect requested by the plugin. */
    textEffect: PluginComposerTextEffect | null;
    textEffectCalls: Array<PluginComposerTextEffect | null>;
    /** Whether this plugin currently holds the composer input lock. */
    inputLocked: boolean;
    inputLockCalls: boolean[];
    quotes: string[];
    mentions: PluginComposerMention[];
    focusCount: number;
    /**
     * Every `submit` the plugin ran, in order. The harness composer has no
     * submit pipeline of its own, so it records the options and clears the
     * draft — enough to assert what a picker scheduled and that it tidied up.
     */
    submits: ComposerSubmitOptions[];
    /**
     * Every `setSelection` the harness composer accepted, in order. The
     * harness has no pickers of its own, so it merges accepted fields into
     * its current selection and returns that snapshot. A thread drops
     * project and environment because it has no pickers for them. The
     * queued-message scope rejects, as the app does.
     */
    selections: ComposerSelection[];
}
/** One recorded `experimental_useSidebarThreadActions()` call. */
interface SidebarActionCall {
    method: keyof PluginSidebarThreadActions;
    threadId?: string;
    options?: Record<string, unknown>;
    title?: string;
    pinned?: boolean;
    read?: boolean;
}
/**
 * One recorded `experimental_useSidebarNavigation()` action, or a split drag
 * started from `experimental_useSidebarNavigationSplit()` (`beginSplitDrag`).
 */
interface SidebarNavigationCall {
    method: keyof ExperimentalSidebarNavigationActions | "beginSplitDrag";
    itemId?: string;
    itemIds?: string[];
    isVisible?: boolean;
    openInSplit?: boolean;
}
/**
 * Install the test runtime at `globalThis.__bbPluginRuntime.pluginSdkApp`,
 * plus the React the `@get-bb/plugin-sdk/app` components render through.
 * Idempotent per module instance. Call it before the first SDK hook runs or
 * SDK component renders; when the plugin's modules are imported does not
 * matter.
 */
declare function installTestPluginRuntime(): void;
interface CapturedPluginApp {
    homepageSections: PluginHomepageSectionRegistration[];
    settingsSections: PluginSettingsSectionRegistration[];
    appOverlays: ExperimentalAppOverlayRegistration[];
    navPanels: PluginNavPanelRegistration[];
    threadPanelActions: PluginThreadPanelActionRegistration[];
    newThreadPanelActions: PluginNewThreadPanelActionRegistration[];
    composerCustomizations: ComposerCustomization[];
    pendingInteractions: PluginPendingInteractionRegistration[];
    sidebarFooterActions: PluginSidebarFooterActionRegistration[];
    experimentalSidebarFooterItems: CollectedExperimentalSidebarFooterItem[];
    experimentalSidebarNavigations: ExperimentalSidebarNavigationRegistration[];
    experimentalSidebarHeaders: ExperimentalSidebarHeaderRegistration[];
    threadLists: PluginThreadListRegistration[];
    threadHeaderActions: PluginThreadHeaderActionRegistration[];
    browserToolbarActions: ExperimentalPluginBrowserToolbarActionRegistration[];
    fileOpeners: PluginFileOpenerRegistration[];
    sourceCodeRenderers: PluginSourceCodeRendererRegistration[];
    diffRenderers: PluginDiffRendererRegistration[];
    messageDirectives: PluginMessageDirectiveRegistration[];
    messageActions: PluginMessageActionRegistration[];
    providerIcons: CollectedPluginProviderIconRegistration[];
    icons: ExperimentalIconRegistration[];
    timelineRenderers: PluginTimelineRendererRegistration[];
    environmentProviderInputs: PluginEnvironmentProviderInputsRegistration[];
    machineProviderInputs: PluginMachineProviderInputsRegistration[];
    contentScripts: PluginContentScriptRegistration[];
}
type PluginAppModule = {
    default: unknown;
};
type PluginAppSource = PluginAppDefinition | PluginAppModule | (() => Promise<PluginAppDefinition | PluginAppModule>);
/**
 * Install the test runtime, resolve the plugin app definition, and capture
 * its slot registrations. Pass the imported module, its default export, or a
 * thunk (`() => import("../app.tsx")`).
 */
declare function loadPluginApp(source: PluginAppSource): Promise<CapturedPluginApp>;
interface ContentScriptTestMountOptions {
    pluginId: string;
    /** Defaults to 1. Pass the host generation you want the plugin to observe. */
    generation?: number;
    /**
     * Simulate an older compatible host that predates the optional experimental
     * thread-row status API. Current-host behavior is enabled by default.
     */
    omitExperimentalThreadRowStatus?: boolean;
}
interface ContentScriptThreadRowStatusCall {
    threadId: string;
    status: PluginComposerThreadRowStatus | null;
}
interface MountedPluginContentScripts {
    inspection: {
        readonly mountedIds: readonly string[];
        readonly signal: AbortSignal;
        readonly disposed: boolean;
        readonly threadRowStatusCalls: readonly ContentScriptThreadRowStatusCall[];
        getThreadRowStatus(threadId: string): PluginComposerThreadRowStatus | null;
    };
    lifecycle: {
        /** Abort, then run returned cleanup functions once in reverse order. */
        dispose(): Promise<void>;
    };
}
/**
 * Mount captured content scripts with host-faithful ordering and rollback.
 * Call this once per simulated app window; each result owns an independent
 * AbortSignal and cleanup lifecycle.
 */
declare function mountPluginContentScripts(app: CapturedPluginApp, options: ContentScriptTestMountOptions): Promise<MountedPluginContentScripts>;
type PluginRpcTestHandlers<Contract extends PluginRpcContract> = {
    [Method in keyof Contract]: (input: StandardSchemaV1InferInput<Contract[Method]["input"]>) => PluginRpcResult<Contract[Method]> | Promise<PluginRpcResult<Contract[Method]>>;
};
interface RenderSlotOptions<Contract extends PluginRpcContract = PluginRpcContract> {
    /**
     * Backing handlers for `useRpc().call`: method name → implementation.
     * Inputs and results are JSON-round-tripped like the wire; a method
     * without a handler rejects, and a throwing handler rejects with its
     * message (what the real rpc client surfaces).
     */
    rpc?: PluginRpcTestHandlers<Contract>;
    /** `useSettings()` values; omitted → `{ values: undefined, isLoading: false }`. */
    settings?: Record<string, string | number | boolean>;
    /** `useBbContext()` selection; both default to null. */
    context?: {
        projectId?: string | null;
        threadId?: string | null;
    };
    /** `experimental_usePluginId()` value; defaults to `test-plugin`. */
    pluginId?: string;
    /** Initial `useRealtimeConnectionState()` value; defaults to `connected`. */
    realtimeConnectionState?: PluginRealtimeConnectionState;
    /** Initial state for this render's isolated composer scope and view. */
    composer?: {
        text?: string;
        /** Mention pills already in `text`, with ranges into it. */
        mentions?: readonly ComposerMention[];
        scope?: PluginComposerScope;
        attachmentCount?: number;
        attachments?: readonly ComposerAttachment[];
        layout?: "compact" | "expanded";
        isRunning?: boolean;
        isSubmitting?: boolean;
        selection?: ComposerSelection;
        /**
         * What `submittingBlockedReason` reports, and what `submit` rejects
         * with. Omitted → "Type a message first." while the draft is empty,
         * "Submitting..." while `isSubmitting`, otherwise null.
         */
        submittingBlockedReason?: string | null;
    };
    /**
     * Threads and projects `experimental_useSidebarThreads()` reports. Omitted →
     * a ready, empty list. Pass `{ status: "loading" }` to test that branch.
     */
    sidebarThreads?: Partial<PluginSidebarThreadsState>;
    /**
     * The provider directory `experimental_useProviders()` reports. Omitted →
     * a ready, empty list. Pass `{ status: "loading" }` to test that branch.
     */
    providers?: Partial<PluginProvidersState>;
    /**
     * The code theme `experimental_useCodeTheme()` reports. Omitted → a light
     * mode with no resolved document, the state a plugin sees on first paint.
     */
    codeTheme?: Partial<PluginCodeThemeState>;
    branchesState?: Partial<BranchesState>;
    /** Checkout facts `experimental_useCheckoutState()` reports. */
    checkoutState?: Partial<CheckoutState>;
    /**
     * Pull requests `experimental_useSidebarThreadPullRequest()` reports, keyed
     * by thread id. Omitted → every thread reports none.
     */
    sidebarPullRequests?: Record<string, PluginSidebarPullRequest>;
    /**
     * Thread ids `useSidebarThreadDraft()` and `useSidebarThreadDraftIds()`
     * report as holding an unsent draft. Omitted → none.
     */
    sidebarDraftThreadIds?: readonly string[];
    /**
     * Row statuses `useSidebarThreadRowStatus()` reports, keyed by thread id.
     * Omitted → every thread reports null.
     */
    sidebarRowStatuses?: Record<string, PluginSidebarThreadRowStatus>;
    /**
     * Shortcuts `useSidebarThreadShortcut()` reports, keyed by thread id, as
     * if the app command modifier were held. Omitted → every thread reports
     * null.
     */
    sidebarShortcuts?: Record<string, PluginSidebarThreadShortcut>;
    /** The split layout `useSidebarSplitLayout()` reports. Omitted → null. */
    sidebarSplitLayout?: PluginSidebarSplitLayout;
    /**
     * Items and the active item `experimental_useSidebarNavigation()` reports.
     * Omitted → no items. Actions are recorded in
     * `inspection.sidebarNavigationCalls` and do not change the items.
     */
    sidebarNavigation?: {
        items?: readonly ExperimentalSidebarNavigationItem[];
        activeItemId?: string | null;
        isShortcutModifierHeld?: boolean;
    };
    /**
     * The environment provider catalog `useEnvironmentProviders()` reports.
     * Omitted → a ready, empty list. Pass `{ status: "loading" }` to test that
     * branch.
     */
    environmentProviders?: Partial<PluginEnvironmentProvidersState>;
    /**
     * Fakes for `useSdk()`, one partial object per area. Calls are recorded
     * in `inspection.sdkCalls`; a call to a method you did not provide throws.
     */
    sdk?: PluginSdkTestFakes;
    /** Host acceptance for `useBbNavigate().openThreadPanel`. */
    openThreadPanel?: (options: Parameters<BbNavigate["openThreadPanel"]>[0]) => boolean;
    /** Host acceptance for URL intents from the hook or `UrlLink`. */
    openUrl?: (url: string) => boolean;
    /** Host acceptance for preview intents from the hook or file link. */
    openFilePreview?: (options: ExperimentalFileOpenOptions) => boolean;
    /** Host acceptance for preferred-external file intents. */
    openFileExternally?: (options: ExperimentalFileOpenOptions) => boolean;
    /** Host acceptance for an owner-scoped fixed-tab selection. */
    experimental_openFixedTab?: (call: ExperimentalFixedTabOpenCall) => boolean;
    /** Initial session target visible to `experimental_useFixedTabTarget`. */
    experimental_fixedTabTarget?: {
        panelId: string;
        tabId: string;
        target: JsonValue;
    };
}
/** Host-originated inputs a slot test can drive deterministically. */
interface RenderedSlotBehaviorDrivers {
    /**
     * Push a realtime event to `useRealtime(channel, …)` subscribers, wrapped
     * in act. The payload is JSON-round-tripped like `bb.realtime.publish`.
     */
    emitRealtime(channel: string, payload: unknown): Promise<void>;
    /** Drive the lifecycle of the same connection used by realtime events. */
    setRealtimeConnectionState(state: PluginRealtimeConnectionState): Promise<void>;
    /** Replace composer text as a host-originated edit, wrapped in act. */
    setComposerText(text: string): Promise<void>;
    /** Replace the scope snapshots returned by composer hooks, wrapped in act. */
    setComposerScope(scope: PluginComposerScope): Promise<void>;
}
/** Read-only call/write logs produced while the slot is mounted. */
interface RenderedSlotInspectionState {
    /** Every `useRpc().call`, in order. */
    readonly rpcCalls: RpcCall[];
    /** Every `useBbNavigate()` call, in order. */
    readonly navigateCalls: NavigateCall[];
    /** Every validated `experimental_useAppPanel().openFixedTab` call. */
    readonly experimental_fixedTabOpenCalls: ExperimentalFixedTabOpenCall[];
    /** Every `experimental_useSidebarThreadActions()` call, in order. */
    readonly sidebarActionCalls: SidebarActionCall[];
    /**
     * Every `experimental_useSidebarNavigation()` action and navigation split
     * drag, in order.
     */
    readonly sidebarNavigationCalls: SidebarNavigationCall[];
    /** Every `useSdk()` call, in order, as `"<area>.<method>"`. */
    readonly sdkCalls: SdkCall[];
    /** Everything written through `useComposer()`. */
    readonly composer: ComposerLog;
}
/** Explicit mount controls, separate from behavior inputs and call logs. */
interface RenderedSlotLifecycleControls {
    rerender(ui: ReactNode): void;
    unmount(): void;
}
/**
 * Testing Library result plus BB-specific helpers. Direct members are
 * retained for compatibility; named views make intent explicit in new tests.
 */
interface RenderedSlot extends RenderResult, RenderedSlotBehaviorDrivers, RenderedSlotInspectionState {
    readonly behavior: RenderedSlotBehaviorDrivers;
    readonly inspection: RenderedSlotInspectionState;
    readonly lifecycle: RenderedSlotLifecycleControls;
}
declare function renderSlot<Props extends object, Contract extends PluginRpcContract = PluginRpcContract>(registration: {
    component: ComponentType<Props>;
}, props: Props, options?: RenderSlotOptions<Contract>): RenderedSlot;

export { installTestPluginRuntime, loadPluginApp, mountPluginContentScripts, renderSlot };
export type { CapturedPluginApp, ComposerLog, ContentScriptTestMountOptions, ContentScriptThreadRowStatusCall, ExperimentalFixedTabOpenCall, MountedPluginContentScripts, NavigateCall, PluginAppSource, PluginRpcTestHandlers, PluginSdkTestFakes, RenderSlotOptions, RenderedSlot, RenderedSlotBehaviorDrivers, RenderedSlotInspectionState, RenderedSlotLifecycleControls, RpcCall, SdkCall, SidebarActionCall, SidebarNavigationCall };
